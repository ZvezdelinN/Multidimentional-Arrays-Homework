﻿/*

Problem 3. Sequence n matrix
• We are given a matrix of strings of size  N x M . Sequences in the matrix we define as sets of several neighbour elements located on the same line, column or diagonal.
• Write a program that finds the longest sequence of equal strings in the matrix.

Example:


matrix              result

ha fifi ho hi       ha, ha, ha 
fo ha hi xx 
xxx ho ha xx 

s qq s              s, s, s
pp pp s 
pp qq s 
*/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sequence_n_matrix
{
    class Program
    {
        static void Main(string[] args)
        {
            string singleString = "";
            string[,] matrixOfStrings = new string[3,4]{
                {"ha","fifi","hi","hi"},
                {"fo",  "ha","hi","xx"}, 
                {"xxx", "ho", "hi", "xx"}
            };
            int currentCounter = 1;
            int BestcurrentCounter = 0;
            

            //Checking all rows
            for (int i = 0; i < matrixOfStrings.GetLength(0); i++)
            {
                currentCounter = 1;
                for (int j = 1; j < matrixOfStrings.GetLength(1); j++)
                {
                    string str1 = matrixOfStrings[i, j];
                    string str2 = matrixOfStrings[i, j - 1];
                    if (matrixOfStrings[i, j] == matrixOfStrings[i, j - 1])
                    {
                        currentCounter++;
                        
                    }
                    if (currentCounter > BestcurrentCounter)
                    {
                        BestcurrentCounter = currentCounter;
                        singleString = str2;
                    }
                }
            }


            //Checking all columns
            for (int i = 0; i < matrixOfStrings.GetLength(1); i++)
            {
                currentCounter = 1;
                
                for (int j = 1; j <= matrixOfStrings.GetLength(0) - 1; j++)
                {
                    string str1 = matrixOfStrings[j, i];
                    string str2 = matrixOfStrings[j - 1, i];
                    if (matrixOfStrings[j, i] == matrixOfStrings[j - 1, i])
                    {
                        currentCounter++;
                    }
                    if (currentCounter > BestcurrentCounter)
                    {
                        BestcurrentCounter = currentCounter;
                        singleString = str2;
                    }
                }

            }

            
            //Checking the diagonal from left top to right bottom
            currentCounter = 1;
            for (int i = 1,j=1; i <= matrixOfStrings.GetLength(0) - 1; i++,j++)
            {
                string str1 = matrixOfStrings[j, i];
                string str2 = matrixOfStrings[j - 1, i-1];
                if (matrixOfStrings[i, j] == matrixOfStrings[i - 1, j - 1])
                {
                    currentCounter++;
                }
                if (currentCounter > BestcurrentCounter)
                {
                    BestcurrentCounter = currentCounter;
                    singleString = str2;
                }
            }


            //Checking the diagonal from right top to left bottom
            for (int i = 1, j = 1; i <= matrixOfStrings.GetLength(0) - 1; i++, j++)
            {
                currentCounter = 1;
                
                string str1 = matrixOfStrings[j, i];
                string str2 = matrixOfStrings[j - 1, i - 1];
                if (matrixOfStrings[i, j] == matrixOfStrings[i - 1, j - 1])
                {
                    currentCounter++;
                }
                if (currentCounter > BestcurrentCounter)
                {
                    BestcurrentCounter = currentCounter;
                    singleString = str2;
                }
            }

           
            //Printing the result 
            for (int i = 0; i < BestcurrentCounter; i++)
            {
                    Console.Write("{0,3}, ",singleString);
            }
           
        }
    }
}
