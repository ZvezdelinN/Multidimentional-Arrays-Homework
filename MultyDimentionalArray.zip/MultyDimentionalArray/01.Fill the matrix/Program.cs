﻿/*
Problem 1. Fill the matrix
• Write a program that fills and prints a matrix of size  (n, n)  as shown below:

Example for  n=4 :


a)

1 5 9 13 
2 6 10 14 
3 7 11 15 
4 8 12 16 
 
b)
 
1 8 9 16 
2 7 10 15 
3 6 11 14 
4 5 12 13 
 
c)
 
7 11 14 16 
4 8 12 15 
2 5 9 13 
1 3 6 10 
 
d)*
 
1 12 11 10 
2 13 16 9 
3 14 15 8 
4 5 6 7 
*/ 

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _01.Fill_the_matrix
{
    class Program
    {

        public static void PrintArray(int[,] intArray)
        {
            for (int i = 0; i < intArray.GetLength(0); i++)
            {
                Console.WriteLine("".PadLeft(6));
                for (int j = 0; j < intArray.GetLength(1); j++)
                {
                    Console.Write("{0,2} ", intArray[i,j]);
                }
                Console.WriteLine();
            }
        }

        public static void AvariantOfMatrix(int intNMatrix)
        {
            int intCounter = 0;
            int[,] intArray = new int[intNMatrix, intNMatrix];
            for (int i = 0; i < intArray.GetLength(0); i++)
            {
                for (int j = 0; j < intArray.GetLength(1); j++)
                {
                    intCounter++;
                    intArray[j, i] = intCounter;
                }
            }

            PrintArray(intArray);
        }

        public static void BvariantOfMatrix(int intNMatrix)
        {
            int intCounter = 0;
            int[,] intArray = new int[intNMatrix, intNMatrix];
            for (int i = 0; i < intArray.GetLength(0); i++)
            {
                if (i % 2 == 0)
                {
                    for (int j = 0; j < intArray.GetLength(1); j++)
                    {
                        intCounter++;
                        intArray[j, i] = intCounter;
                    }
                }
                else
                {
                    for (int j = intArray.GetLength(1)-1; j >= 0; j--)
                    {
                        intCounter++;
                        intArray[j, i] = intCounter;
                    }
                }
            }

            PrintArray(intArray);
        }

        public static void CvariantOfMatrix(int intNMatrix)
        {
            int side = intNMatrix;
            int[,] matrix = new int[side, side];
            int maxRotation = side * side;
            int row = 0;
            int col = 1;
            int ColCounter = 1;

            matrix[0, 0] = ColCounter;

            for (int i = 1; i < maxRotation; i++)
            {
                
                if (col + 1 > side)
                {
                    col--;
                    row++;
                }

                if(row + 1 > side)
                {
                    ColCounter--;
                    col += ColCounter;
                    row -= ColCounter - 1;
                }


                matrix[row, col] = i + 1;


                if (col - 1 < 0)
                {
                    ColCounter++;
                    col += ColCounter;
                    row -= ColCounter - 1;
                }

                else
                {
                    col--;
                    row++;

                }
            }
            PrintArray(matrix);
        }

        public static void DvariantOfMatrix(int intNMatrix)
        {
            int side = intNMatrix;
            int[,] matrix = new int[side, side];
            int maxRotation = side * side;
            string Direction="down";
            int row = 0;
            int col = 0;

            for (int i = 1; i <= maxRotation; i++)
            {

                if (Direction == "down" && (row > side-1 || matrix[row,col]!=0))
                {
                    Direction = "right";
                    col++;
                    row--;
                }

                if (Direction == "right" && (col > side - 1 || matrix[row, col] != 0))
                {
                    Direction = "up";
                    row--;
                    col--;
                }

                if (Direction == "up" && (row < 0 || matrix[row,col]!=0))
                {
                    Direction = "left";
                    col--;
                    row++;
                }

                if (Direction == "left" && (col < 0 || matrix[row,col]!=0)) 
                {
                    Direction = "down";
                    row++;
                    col++; 
                }

                matrix[row, col] = i;

               if(Direction=="right")
               {
                   col++;
               }

               if (Direction == "down")
               {
                   row++;
               }

               if (Direction == "left")
               {
                   col--;
               }

               if (Direction == "up")
               {
                   row--;
               }

            }


            PrintArray(matrix);
        }

        static void Main(string[] args)
        {
            int intNMatrix;

            Console.Write("Please, enter the size of the matrix : ");
            intNMatrix = int.Parse(Console.ReadLine());

            Console.WriteLine("a)");
            AvariantOfMatrix(intNMatrix);
            Console.WriteLine();

            Console.WriteLine("b)");
            BvariantOfMatrix(intNMatrix);
            Console.WriteLine();

            Console.WriteLine("c)");
            CvariantOfMatrix(intNMatrix);
            Console.WriteLine();

            Console.WriteLine("d)");
            DvariantOfMatrix(intNMatrix);
            Console.WriteLine();
        }
    }
}
