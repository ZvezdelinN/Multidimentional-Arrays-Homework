﻿/*
Problem 4. Binary search
• Write a program, that reads from the console an array of  N  integers and an integer  K , sorts the array and using the method  Array.BinSearch()  finds the largest number in the array which is ≤  K . 
 */ 

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _04.Binary_search
{
    class Program
    {
        static void Main(string[] args)
        {
            int LengthOfArray, aNumberToCompare;
            int[] ArrayOfInteger;

            //Enetring the array's length
            Console.Write("Please, enter the array's length : ");
            LengthOfArray = int.Parse(Console.ReadLine());

            //Alocating the array
            ArrayOfInteger=new int[LengthOfArray]; 

            for (int i = 0; i < LengthOfArray; i++)
            {
                Console.Write("Array element [{0}] : ",i);
                ArrayOfInteger[i] = int.Parse(Console.ReadLine());
            }

            //Entering the number to compare with
            Console.Write("Please, enter a number to compare :");
            aNumberToCompare = int.Parse(Console.ReadLine());

            //Sorting the array
            Array.Sort(ArrayOfInteger);

            int theSearchingNumber = ArrayOfInteger[ArrayOfInteger.Length-1];

            for (int i = ArrayOfInteger.Length - 1; i >= 0; i--)
            {
                if (theSearchingNumber > aNumberToCompare)
                {
                    theSearchingNumber = ArrayOfInteger[i];
                }
            }

            int possition = Array.BinarySearch(ArrayOfInteger,theSearchingNumber);

            Console.WriteLine("The numer {0}, which is <= {1} is at the possition {2}!",theSearchingNumber,aNumberToCompare,possition);
        }
    }
}
