﻿/*
Problem 2. Maximal sum
• Write a program that reads a rectangular matrix of size  N x M  and finds in it the square  3 x 3  that has maximal sum of its elements.
*/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _02.Maximal_sum
{
    class Program
    {
        static void Main(string[] args)
        {
            int rows=0;
            int cols=0;
            int[,] matrix;

            Console.Write("Please, enter number of rows : ");
            rows=int.Parse(Console.ReadLine());

            Console.WriteLine();

            Console.Write("Please, enter number of rows : ");
            cols = int.Parse(Console.ReadLine());

            matrix=new int[rows,cols];
            Random rdm = new Random();

            for (int i = 0; i < rows; i++)
            {
                for (int j = 0; j < cols; j++)
                {
                    matrix[i, j] = rdm.Next(0, rows * cols);
                }
            }


            for (int i = 0; i < rows; i++)
            {
                for (int j = 0; j < cols; j++)
                {
                    Console.Write("{0,3} ", matrix[i, j]);
                }
                Console.WriteLine();
            }


            int MaxSum = int.MinValue;
            int CurrentSum = 0;
            int bestStart = 0;
            int currentStart = 0;
            int bestEnd = 0;
            int CurrentEnd = 0;
            if(rows < 3 || cols < 3)
            {
                Console.WriteLine("The number of rows and cols must be > 3");
                return;
            }
            else
            {
                for (int i = 0; i <= rows - 3; i++)
                {
                    for (int j = 0; j <= cols - 3; j++)
                    {
                        CurrentSum = 0;
                        currentStart = i;
                        CurrentEnd = j;
                        for (int n = i; n < i+3; n++)
                        {
                            for (int m = j; m < j+3; m++)
                            {
                                CurrentSum += matrix[n, m];
                            }
                        }
                        if(CurrentSum > MaxSum)
                        {
                            MaxSum = CurrentSum;
                            bestStart = currentStart;
                            bestEnd = CurrentEnd;
                        }
                    }
                }

                
                Console.WriteLine(MaxSum);

                for (int i = bestStart; i < bestStart+3; i++)
                {
                    for (int j = bestEnd; j < bestEnd+3; j++)
                    {
                        Console.Write("{0,3} ", matrix[i, j]);
                    }
                    Console.WriteLine();
                }
            }
        }
    }
}
